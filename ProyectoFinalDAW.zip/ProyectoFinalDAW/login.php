<?php // login.php
 $hn = 'localhost';
 $db = 'levelup_video';
 $un = 'root';
 $pw = '';
?>